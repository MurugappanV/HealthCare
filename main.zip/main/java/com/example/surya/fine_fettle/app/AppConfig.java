package com.example.surya.fine_fettle.app;

public class AppConfig {



    public static String Register="Doc_registration.php";
    public static String Login="Doc_Login.php";
    public static String Profile="Doc_Profile.php";
    public static String Alaram_message="Alaram_message.php";
    public static String Booking_history="Patient_booking_history.php";
    public static String Patient_Prescription="Patient_prescription.php";
    public static String Patient_List="Patient_list.php";
    public static String Accept="Doc_Accept_booking.php";


}

