package com.example.surya.fine_fettle.app;

/**
 * Created by 9DOTS04 on 11/21/2016.
 */

public interface Root {



           // String URL = "http://10.13.1.17/FineFettleWebservice/web-services/";
           //String URL = "http://35.204.108.96/FineFettleWebservice/web-services/";
           String URL = "http://192.168.43.109/FineFettleWebservice/web-services/";
    //String URL = "http://localhost/FineFettleWebservice/web-services/";
}
